# pyLLS
### a Python library for missing gene value imputation using local least square algorithm

One algorithm that is particularly effective at imputing missing values is the Local Least Square (LLS) algorithm.<br>
We introduce our pyLLS by implementing the LLS into python framework.<br>
Our pyLLS offers more options and is significantly faster than LLS in R.

Please report bugs to Sejin Oh, at <agicic@naver.com> or at <https://github.com/osj118/pyLLS/issues>.